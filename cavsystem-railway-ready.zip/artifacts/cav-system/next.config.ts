import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Ensure compatibility with the monorepo workspace packages
  transpilePackages: ["@workspace/api-client-react"],
};

export default nextConfig;
