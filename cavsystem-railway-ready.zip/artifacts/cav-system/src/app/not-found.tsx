import Link from "next/link";

export default function NotFound() {
  return (
    <div className="min-h-[60vh] flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-6xl font-bold text-muted-foreground/30">404</h1>
        <p className="text-xl font-semibold mt-4">Pagina nao encontrada</p>
        <p className="text-muted-foreground mt-2 text-sm">A pagina que voce procura nao existe.</p>
        <Link href="/">
          <button className="mt-6 px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 transition-colors">
            Voltar ao Dashboard
          </button>
        </Link>
      </div>
    </div>
  );
}
