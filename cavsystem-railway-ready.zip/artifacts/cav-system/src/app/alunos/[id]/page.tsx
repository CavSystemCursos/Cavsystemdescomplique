"use client";

import { useParams } from "next/navigation";
import Link from "next/link";
import { useGetStudent, getGetStudentQueryKey, useGetStudentEnrollments, getGetStudentEnrollmentsQueryKey, useListPayments, getListPaymentsQueryKey } from "@workspace/api-client-react";
import { formatDate, formatCurrency, statusLabel, statusColor } from "@/lib/format";
import { ArrowLeft, Mail, Phone, FileText, GraduationCap, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export default function StudentDetailPage() {
  const params = useParams();
  const id = Number(params.id);

  const { data: student, isLoading } = useGetStudent(id, {
    query: { enabled: !!id, queryKey: getGetStudentQueryKey(id) },
  });
  const { data: enrollments } = useGetStudentEnrollments(id, {
    query: { enabled: !!id, queryKey: getGetStudentEnrollmentsQueryKey(id) },
  });
  const { data: payments } = useListPayments(
    { studentId: id },
    { query: { enabled: !!id, queryKey: getListPaymentsQueryKey({ studentId: id }) } },
  );

  if (isLoading) return <div className="h-48 bg-muted animate-pulse rounded" />;

  if (!student) return (
    <div className="text-center py-12">
      <p className="text-muted-foreground">Aluno nao encontrado.</p>
      <Link href="/alunos"><Button variant="outline" className="mt-4">Voltar</Button></Link>
    </div>
  );

  return (
    <div className="max-w-3xl space-y-5">
      <div className="flex items-center gap-3">
        <Link href="/alunos"><Button variant="ghost" size="icon"><ArrowLeft className="w-4 h-4" /></Button></Link>
        <div className="flex-1">
          <h1 className="text-2xl font-bold tracking-tight">{student.name}</h1>
          <div className="flex items-center gap-2 mt-1">
            <span className={cn("text-xs font-medium px-2 py-0.5 rounded-full", statusColor(student.status))}>{statusLabel(student.status)}</span>
            <span className="text-muted-foreground text-sm">Desde {formatDate(student.createdAt)}</span>
          </div>
        </div>
        <Link href={`/alunos/${student.id}/editar`}><Button variant="outline" size="sm">Editar</Button></Link>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Informacoes</CardTitle></CardHeader>
        <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex items-center gap-3">
            <Mail className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <div><p className="text-xs text-muted-foreground">Email</p><p className="text-sm font-medium">{student.email}</p></div>
          </div>
          {student.phone && (
            <div className="flex items-center gap-3">
              <Phone className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <div><p className="text-xs text-muted-foreground">Telefone</p><p className="text-sm font-medium">{student.phone}</p></div>
            </div>
          )}
          {student.cpf && (
            <div className="flex items-center gap-3">
              <FileText className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <div><p className="text-xs text-muted-foreground">CPF</p><p className="text-sm font-medium">{student.cpf}</p></div>
            </div>
          )}
          {student.notes && (
            <div className="sm:col-span-2">
              <p className="text-xs text-muted-foreground mb-1">Observacoes</p>
              <p className="text-sm">{student.notes}</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center gap-2 pb-2">
          <GraduationCap className="w-4 h-4 text-muted-foreground" />
          <CardTitle className="text-base">Matriculas ({enrollments?.length ?? 0})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {!enrollments || enrollments.length === 0 ? (
            <p className="text-muted-foreground text-sm px-4 pb-4">Nenhuma matricula</p>
          ) : (
            <ul className="divide-y">
              {enrollments.map((e) => (
                <li key={e.id} className="px-4 py-3 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">{e.courseName}</p>
                    <p className="text-xs text-muted-foreground">{formatDate(e.enrolledAt)}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground">{formatCurrency(e.coursePrice)}</span>
                    <span className={cn("text-xs font-medium px-2 py-0.5 rounded-full", statusColor(e.status))}>{statusLabel(e.status)}</span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center gap-2 pb-2">
          <DollarSign className="w-4 h-4 text-muted-foreground" />
          <CardTitle className="text-base">Pagamentos ({payments?.length ?? 0})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {!payments || payments.length === 0 ? (
            <p className="text-muted-foreground text-sm px-4 pb-4">Nenhum pagamento registrado</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b text-left"><th className="px-4 py-2.5 font-medium text-muted-foreground">Descricao</th><th className="px-4 py-2.5 font-medium text-muted-foreground">Vencimento</th><th className="px-4 py-2.5 font-medium text-muted-foreground">Valor</th><th className="px-4 py-2.5 font-medium text-muted-foreground">Status</th></tr></thead>
                <tbody className="divide-y">
                  {payments.map((p) => (
                    <tr key={p.id}>
                      <td className="px-4 py-3">{p.description}</td>
                      <td className="px-4 py-3 text-muted-foreground">{formatDate(p.dueDate)}</td>
                      <td className="px-4 py-3 font-medium">{formatCurrency(p.amount)}</td>
                      <td className="px-4 py-3"><span className={cn("text-xs font-medium px-2 py-0.5 rounded-full", statusColor(p.status))}>{statusLabel(p.status)}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
