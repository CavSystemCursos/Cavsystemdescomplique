"use client";

import { useParams } from "next/navigation";
import Link from "next/link";
import { useGetCourse, getGetCourseQueryKey, useGetCourseStudents, getGetCourseStudentsQueryKey } from "@workspace/api-client-react";
import { formatCurrency, formatDate, statusLabel, statusColor } from "@/lib/format";
import { ArrowLeft, Users, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export default function CourseDetailPage() {
  const params = useParams();
  const id = Number(params.id);

  const { data: course, isLoading } = useGetCourse(id, { query: { enabled: !!id, queryKey: getGetCourseQueryKey(id) } });
  const { data: students } = useGetCourseStudents(id, { query: { enabled: !!id, queryKey: getGetCourseStudentsQueryKey(id) } });

  if (isLoading) return <div className="h-48 bg-muted animate-pulse rounded" />;
  if (!course) return (
    <div className="text-center py-12">
      <p className="text-muted-foreground">Curso nao encontrado.</p>
      <Link href="/cursos"><Button variant="outline" className="mt-4">Voltar</Button></Link>
    </div>
  );

  return (
    <div className="max-w-3xl space-y-5">
      <div className="flex items-center gap-3">
        <Link href="/cursos"><Button variant="ghost" size="icon"><ArrowLeft className="w-4 h-4" /></Button></Link>
        <div className="flex-1">
          <h1 className="text-2xl font-bold tracking-tight">{course.name}</h1>
          <div className="flex items-center gap-2 mt-1">
            <span className={cn("text-xs font-medium px-2 py-0.5 rounded-full", statusColor(course.status))}>{statusLabel(course.status)}</span>
            <span className="text-muted-foreground text-sm">Criado em {formatDate(course.createdAt)}</span>
          </div>
        </div>
        <Link href={`/cursos/${course.id}/editar`}><Button variant="outline" size="sm">Editar</Button></Link>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold text-primary">{formatCurrency(course.price)}</p><p className="text-xs text-muted-foreground mt-1">Valor</p></CardContent></Card>
        <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold">{course.studentCount}</p><p className="text-xs text-muted-foreground mt-1">Alunos</p></CardContent></Card>
        {course.durationHours && <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold">{course.durationHours}h</p><p className="text-xs text-muted-foreground mt-1">Duracao</p></CardContent></Card>}
      </div>

      {course.description && (
        <Card>
          <CardHeader><CardTitle className="text-base">Descricao</CardTitle></CardHeader>
          <CardContent><p className="text-sm text-muted-foreground">{course.description}</p></CardContent>
        </Card>
      )}

      {course.whatsappGroupLink && (
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <ExternalLink className="w-4 h-4 text-green-600 flex-shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Grupo WhatsApp</p>
              <a href={course.whatsappGroupLink} target="_blank" rel="noopener noreferrer" className="text-sm text-green-600 hover:underline break-all">{course.whatsappGroupLink}</a>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="flex flex-row items-center gap-2 pb-2">
          <Users className="w-4 h-4 text-muted-foreground" />
          <CardTitle className="text-base">Alunos Matriculados ({students?.length ?? 0})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {!students || students.length === 0 ? (
            <div className="p-6 text-center">
              <p className="text-muted-foreground text-sm">Nenhum aluno matriculado</p>
              <Link href="/matriculas"><Button variant="outline" size="sm" className="mt-3"><Users className="w-4 h-4 mr-2" />Gerenciar Matriculas</Button></Link>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b text-left"><th className="px-4 py-2.5 font-medium text-muted-foreground">Nome</th><th className="px-4 py-2.5 font-medium text-muted-foreground hidden sm:table-cell">Email</th><th className="px-4 py-2.5 font-medium text-muted-foreground">Status</th></tr></thead>
                <tbody className="divide-y">
                  {students.map((s) => (
                    <tr key={s.id}>
                      <td className="px-4 py-3 font-medium"><Link href={`/alunos/${s.id}`} className="hover:text-primary transition-colors">{s.name}</Link></td>
                      <td className="px-4 py-3 text-muted-foreground hidden sm:table-cell">{s.email}</td>
                      <td className="px-4 py-3"><span className={cn("text-xs font-medium px-2 py-0.5 rounded-full", statusColor(s.status))}>{statusLabel(s.status)}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
