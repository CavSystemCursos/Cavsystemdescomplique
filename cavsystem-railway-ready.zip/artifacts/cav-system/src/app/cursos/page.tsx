"use client";

import { useState } from "react";
import Link from "next/link";
import { useListCourses, useDeleteCourse, getListCoursesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatCurrency, statusLabel, statusColor } from "@/lib/format";
import { Plus, Pencil, Trash2, Eye, BookOpen, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function CoursesPage() {
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState("all");
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const { toast } = useToast();

  const params = statusFilter !== "all" ? { status: statusFilter as "active" | "inactive" } : {};
  const { data: courses, isLoading } = useListCourses(params, { query: { queryKey: getListCoursesQueryKey(params) } });
  const deleteMutation = useDeleteCourse();

  function handleDelete() {
    if (!deleteId) return;
    deleteMutation.mutate({ id: deleteId }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListCoursesQueryKey() }); toast({ title: "Curso removido!" }); setDeleteId(null); },
      onError: () => toast({ title: "Erro ao remover curso", variant: "destructive" }),
    });
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold tracking-tight">Cursos</h1><p className="text-muted-foreground text-sm mt-1">Gerencie seus cursos</p></div>
        <Link href="/cursos/novo"><Button><Plus className="w-4 h-4 mr-2" />Novo Curso</Button></Link>
      </div>
      <div className="flex justify-end">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="all">Todos</SelectItem><SelectItem value="active">Ativos</SelectItem><SelectItem value="inactive">Inativos</SelectItem></SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-40 bg-muted animate-pulse rounded-lg" />)}</div>
      ) : !courses || courses.length === 0 ? (
        <Card><CardContent className="p-12 text-center">
          <BookOpen className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
          <p className="text-muted-foreground text-sm">Nenhum curso encontrado</p>
          <Link href="/cursos/novo"><Button variant="outline" size="sm" className="mt-4"><Plus className="w-4 h-4 mr-2" />Criar Curso</Button></Link>
        </CardContent></Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {courses.map((course) => (
            <Card key={course.id} className="flex flex-col">
              <CardContent className="p-5 flex flex-col gap-3 flex-1">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-sm leading-snug">{course.name}</h3>
                    {course.description && <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{course.description}</p>}
                  </div>
                  <span className={cn("text-xs font-medium px-2 py-0.5 rounded-full flex-shrink-0", statusColor(course.status))}>{statusLabel(course.status)}</span>
                </div>
                <div className="flex items-center gap-4 text-sm">
                  <div><p className="text-xs text-muted-foreground">Valor</p><p className="font-semibold text-primary">{formatCurrency(course.price)}</p></div>
                  <div><p className="text-xs text-muted-foreground">Alunos</p><p className="font-medium">{course.studentCount}</p></div>
                  {course.durationHours && <div><p className="text-xs text-muted-foreground">Duracao</p><p className="font-medium">{course.durationHours}h</p></div>}
                </div>
                {course.whatsappGroupLink && (
                  <a href={course.whatsappGroupLink} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-xs text-green-600 hover:underline">
                    <ExternalLink className="w-3 h-3" />Grupo WhatsApp
                  </a>
                )}
                <div className="flex items-center gap-1 mt-auto pt-2 border-t">
                  <Link href={`/cursos/${course.id}`}><Button variant="ghost" size="icon" className="h-7 w-7"><Eye className="w-3.5 h-3.5" /></Button></Link>
                  <Link href={`/cursos/${course.id}/editar`}><Button variant="ghost" size="icon" className="h-7 w-7"><Pencil className="w-3.5 h-3.5" /></Button></Link>
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => setDeleteId(course.id)}><Trash2 className="w-3.5 h-3.5" /></Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Remover curso?</AlertDialogTitle><AlertDialogDescription>Esta acao nao pode ser desfeita.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">Remover</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
