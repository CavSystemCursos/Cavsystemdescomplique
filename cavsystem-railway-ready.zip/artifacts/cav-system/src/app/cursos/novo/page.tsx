"use client";

import { useRouter } from "next/navigation";
import Link from "next/link";
import { useCreateCourse, getListCoursesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const schema = z.object({
  name: z.string().min(1, "Nome obrigatorio"),
  description: z.string().optional(),
  price: z.coerce.number().min(0),
  durationHours: z.coerce.number().int().optional(),
  status: z.enum(["active", "inactive"]).default("active"),
  whatsappGroupLink: z.string().url("URL invalida").optional().or(z.literal("")),
});
type FormData = z.infer<typeof schema>;

export default function NewCoursePage() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const createMutation = useCreateCourse();
  const { toast } = useToast();

  const form = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", description: "", price: 0, status: "active", whatsappGroupLink: "" },
  });

  function onSubmit(data: FormData) {
    const payload = { ...data, whatsappGroupLink: data.whatsappGroupLink || undefined, description: data.description || undefined, durationHours: data.durationHours || undefined };
    createMutation.mutate({ data: payload }, {
      onSuccess: (course) => { queryClient.invalidateQueries({ queryKey: getListCoursesQueryKey() }); toast({ title: "Curso criado!" }); router.push(`/cursos/${course.id}`); },
      onError: () => toast({ title: "Erro ao criar curso", variant: "destructive" }),
    });
  }

  return (
    <div className="max-w-2xl space-y-5">
      <div className="flex items-center gap-3">
        <Link href="/cursos"><Button variant="ghost" size="icon"><ArrowLeft className="w-4 h-4" /></Button></Link>
        <div><h1 className="text-2xl font-bold tracking-tight">Novo Curso</h1><p className="text-muted-foreground text-sm">Preencha os dados do curso</p></div>
      </div>
      <Card>
        <CardHeader><CardTitle className="text-base">Informacoes do curso</CardTitle></CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField control={form.control} name="name" render={({ field }) => (<FormItem className="sm:col-span-2"><FormLabel>Nome *</FormLabel><FormControl><Input placeholder="Nome do curso" {...field} /></FormControl><FormMessage /></FormItem>)} />
                <FormField control={form.control} name="description" render={({ field }) => (<FormItem className="sm:col-span-2"><FormLabel>Descricao</FormLabel><FormControl><Textarea placeholder="Descricao..." rows={3} {...field} /></FormControl><FormMessage /></FormItem>)} />
                <FormField control={form.control} name="price" render={({ field }) => (<FormItem><FormLabel>Valor (R$) *</FormLabel><FormControl><Input type="number" min={0} step="0.01" {...field} /></FormControl><FormMessage /></FormItem>)} />
                <FormField control={form.control} name="durationHours" render={({ field }) => (<FormItem><FormLabel>Duracao (horas)</FormLabel><FormControl><Input type="number" min={1} {...field} /></FormControl><FormMessage /></FormItem>)} />
                <FormField control={form.control} name="status" render={({ field }) => (
                  <FormItem><FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent><SelectItem value="active">Ativo</SelectItem><SelectItem value="inactive">Inativo</SelectItem></SelectContent>
                    </Select><FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="whatsappGroupLink" render={({ field }) => (<FormItem className="sm:col-span-2"><FormLabel>Link do Grupo WhatsApp</FormLabel><FormControl><Input placeholder="https://chat.whatsapp.com/..." {...field} /></FormControl><FormMessage /></FormItem>)} />
              </div>
              <div className="flex gap-3 pt-2">
                <Button type="submit" disabled={createMutation.isPending}>{createMutation.isPending ? "Salvando..." : "Criar Curso"}</Button>
                <Link href="/cursos"><Button type="button" variant="outline">Cancelar</Button></Link>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
