"use client";

import { useState } from "react";
import { useListEnrollments, getListEnrollmentsQueryKey, useCreateEnrollment, useDeleteEnrollment, useListStudents, getListStudentsQueryKey, useListCourses, getListCoursesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatDate, statusLabel, statusColor } from "@/lib/format";
import { Plus, Trash2, GraduationCap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function EnrollmentsPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [showNew, setShowNew] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [newStudentId, setNewStudentId] = useState("");
  const [newCourseId, setNewCourseId] = useState("");

  const { data: enrollments, isLoading } = useListEnrollments();
  const { data: students } = useListStudents(undefined, { query: { queryKey: getListStudentsQueryKey() } });
  const { data: courses } = useListCourses(undefined, { query: { queryKey: getListCoursesQueryKey() } });
  const createMutation = useCreateEnrollment();
  const deleteMutation = useDeleteEnrollment();

  function handleCreate() {
    if (!newStudentId || !newCourseId) return;
    createMutation.mutate({ data: { studentId: Number(newStudentId), courseId: Number(newCourseId) } }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListEnrollmentsQueryKey() }); queryClient.invalidateQueries({ queryKey: getListStudentsQueryKey() }); toast({ title: "Matricula realizada!" }); setShowNew(false); setNewStudentId(""); setNewCourseId(""); },
      onError: () => toast({ title: "Erro ao realizar matricula", variant: "destructive" }),
    });
  }

  function handleDelete() {
    if (!deleteId) return;
    deleteMutation.mutate({ id: deleteId }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListEnrollmentsQueryKey() }); toast({ title: "Matricula removida!" }); setDeleteId(null); },
      onError: () => toast({ title: "Erro ao remover matricula", variant: "destructive" }),
    });
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold tracking-tight">Matriculas</h1><p className="text-muted-foreground text-sm mt-1">Vincule alunos a cursos</p></div>
        <Button onClick={() => setShowNew(true)}><Plus className="w-4 h-4 mr-2" />Nova Matricula</Button>
      </div>
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-3">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-12 bg-muted animate-pulse rounded" />)}</div>
          ) : !enrollments || enrollments.length === 0 ? (
            <div className="p-12 text-center">
              <GraduationCap className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
              <p className="text-muted-foreground text-sm">Nenhuma matricula encontrada</p>
              <Button variant="outline" size="sm" className="mt-4" onClick={() => setShowNew(true)}><Plus className="w-4 h-4 mr-2" />Matricular Aluno</Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b text-left"><th className="px-4 py-3 font-medium text-muted-foreground">Aluno</th><th className="px-4 py-3 font-medium text-muted-foreground">Curso</th><th className="px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Data</th><th className="px-4 py-3 font-medium text-muted-foreground">Status</th><th className="px-4 py-3 font-medium text-muted-foreground text-right">Acoes</th></tr></thead>
                <tbody className="divide-y">
                  {enrollments.map((e) => (
                    <tr key={e.id} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3 font-medium">{e.studentName}</td>
                      <td className="px-4 py-3 text-muted-foreground">{e.courseName}</td>
                      <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">{formatDate(e.enrolledAt)}</td>
                      <td className="px-4 py-3"><span className={cn("text-xs font-medium px-2 py-1 rounded-full", statusColor(e.status))}>{statusLabel(e.status)}</span></td>
                      <td className="px-4 py-3"><div className="flex justify-end"><Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => setDeleteId(e.id)}><Trash2 className="w-3.5 h-3.5" /></Button></div></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showNew} onOpenChange={setShowNew}>
        <DialogContent>
          <DialogHeader><DialogTitle>Nova Matricula</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>Aluno</Label>
              <Select value={newStudentId} onValueChange={setNewStudentId}>
                <SelectTrigger><SelectValue placeholder="Selecione o aluno" /></SelectTrigger>
                <SelectContent>{students?.filter((s) => s.status === "active").map((s) => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Curso</Label>
              <Select value={newCourseId} onValueChange={setNewCourseId}>
                <SelectTrigger><SelectValue placeholder="Selecione o curso" /></SelectTrigger>
                <SelectContent>{courses?.filter((c) => c.status === "active").map((c) => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNew(false)}>Cancelar</Button>
            <Button onClick={handleCreate} disabled={!newStudentId || !newCourseId || createMutation.isPending}>{createMutation.isPending ? "Matriculando..." : "Matricular"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Remover matricula?</AlertDialogTitle><AlertDialogDescription>Esta acao nao pode ser desfeita.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">Remover</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
