"use client";

import { useState } from "react";
import Link from "next/link";
import { useListPayments, getListPaymentsQueryKey, useMarkPaymentAsPaid, useDeletePayment, getListOverduePaymentsQueryKey, getGetDashboardSummaryQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatCurrency, formatDate, statusLabel, statusColor } from "@/lib/format";
import { Plus, CheckCircle, Trash2, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function FinancialPage() {
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState("all");
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const { toast } = useToast();

  const params = statusFilter !== "all" ? { status: statusFilter as "pending" | "paid" | "overdue" } : {};
  const { data: payments, isLoading } = useListPayments(params, { query: { queryKey: getListPaymentsQueryKey(params) } });
  const markPaidMutation = useMarkPaymentAsPaid();
  const deleteMutation = useDeletePayment();

  function handleMarkPaid(id: number) {
    markPaidMutation.mutate({ id }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListPaymentsQueryKey() }); queryClient.invalidateQueries({ queryKey: getListOverduePaymentsQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); toast({ title: "Pagamento confirmado!" }); },
      onError: () => toast({ title: "Erro ao confirmar pagamento", variant: "destructive" }),
    });
  }

  function handleDelete() {
    if (!deleteId) return;
    deleteMutation.mutate({ id: deleteId }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListPaymentsQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); toast({ title: "Cobranca removida!" }); setDeleteId(null); },
      onError: () => toast({ title: "Erro ao remover cobranca", variant: "destructive" }),
    });
  }

  const totalShown = payments?.reduce((s, p) => s + p.amount, 0) ?? 0;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold tracking-tight">Financeiro</h1><p className="text-muted-foreground text-sm mt-1">Controle de cobranças e pagamentos</p></div>
        <Link href="/financeiro/novo"><Button><Plus className="w-4 h-4 mr-2" />Nova Cobrança</Button></Link>
      </div>
      <div className="flex items-center justify-between gap-3">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os status</SelectItem>
            <SelectItem value="pending">Pendentes</SelectItem>
            <SelectItem value="paid">Pagos</SelectItem>
            <SelectItem value="overdue">Atrasados</SelectItem>
          </SelectContent>
        </Select>
        {payments && payments.length > 0 && (
          <p className="text-sm text-muted-foreground">Total: <span className="font-semibold text-foreground">{formatCurrency(totalShown)}</span></p>
        )}
      </div>
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-3">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-12 bg-muted animate-pulse rounded" />)}</div>
          ) : !payments || payments.length === 0 ? (
            <div className="p-12 text-center">
              <DollarSign className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
              <p className="text-muted-foreground text-sm">Nenhum pagamento encontrado</p>
              <Link href="/financeiro/novo"><Button variant="outline" size="sm" className="mt-4"><Plus className="w-4 h-4 mr-2" />Criar Cobrança</Button></Link>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b text-left"><th className="px-4 py-3 font-medium text-muted-foreground">Aluno</th><th className="px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">Descricao</th><th className="px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">Vencimento</th><th className="px-4 py-3 font-medium text-muted-foreground">Valor</th><th className="px-4 py-3 font-medium text-muted-foreground">Status</th><th className="px-4 py-3 font-medium text-muted-foreground text-right">Acoes</th></tr></thead>
                <tbody className="divide-y">
                  {payments.map((p) => (
                    <tr key={p.id} className={cn("hover:bg-muted/30 transition-colors", p.status === "overdue" && "bg-red-50/50")}>
                      <td className="px-4 py-3 font-medium">{p.studentName}</td>
                      <td className="px-4 py-3 text-muted-foreground hidden sm:table-cell">{p.description}</td>
                      <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">{formatDate(p.dueDate)}</td>
                      <td className="px-4 py-3 font-semibold">{formatCurrency(p.amount)}</td>
                      <td className="px-4 py-3"><span className={cn("text-xs font-medium px-2 py-1 rounded-full", statusColor(p.status))}>{statusLabel(p.status)}</span></td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1 justify-end">
                          {p.status !== "paid" && (
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-green-600 hover:text-green-700" onClick={() => handleMarkPaid(p.id)} disabled={markPaidMutation.isPending} title="Confirmar pagamento">
                              <CheckCircle className="w-3.5 h-3.5" />
                            </Button>
                          )}
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => setDeleteId(p.id)}><Trash2 className="w-3.5 h-3.5" /></Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Remover cobrança?</AlertDialogTitle><AlertDialogDescription>Esta acao nao pode ser desfeita.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">Remover</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
