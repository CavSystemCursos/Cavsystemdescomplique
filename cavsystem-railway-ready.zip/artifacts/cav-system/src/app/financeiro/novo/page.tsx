"use client";

import { useRouter } from "next/navigation";
import Link from "next/link";
import { useCreatePayment, useListStudents, getListStudentsQueryKey, useListCourses, getListCoursesQueryKey, getListPaymentsQueryKey, getGetDashboardSummaryQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const schema = z.object({
  studentId: z.coerce.number().int().min(1, "Selecione um aluno"),
  courseId: z.coerce.number().int().optional(),
  description: z.string().min(1, "Descricao obrigatoria"),
  amount: z.coerce.number().min(0.01, "Valor invalido"),
  dueDate: z.string().min(1, "Data de vencimento obrigatoria"),
  status: z.enum(["pending", "paid", "overdue"]).default("pending"),
});
type FormData = z.infer<typeof schema>;

export default function NewPaymentPage() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const createMutation = useCreatePayment();
  const { toast } = useToast();
  const { data: students } = useListStudents(undefined, { query: { queryKey: getListStudentsQueryKey() } });
  const { data: courses } = useListCourses(undefined, { query: { queryKey: getListCoursesQueryKey() } });

  const form = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { description: "", amount: 0, status: "pending", dueDate: "" },
  });

  function onSubmit(data: FormData) {
    const payload = { ...data, courseId: data.courseId || undefined };
    createMutation.mutate({ data: payload }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListPaymentsQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); toast({ title: "Cobrança criada!" }); router.push("/financeiro"); },
      onError: () => toast({ title: "Erro ao criar cobrança", variant: "destructive" }),
    });
  }

  return (
    <div className="max-w-2xl space-y-5">
      <div className="flex items-center gap-3">
        <Link href="/financeiro"><Button variant="ghost" size="icon"><ArrowLeft className="w-4 h-4" /></Button></Link>
        <div><h1 className="text-2xl font-bold tracking-tight">Nova Cobrança</h1><p className="text-muted-foreground text-sm">Crie uma nova cobrança para um aluno</p></div>
      </div>
      <Card>
        <CardHeader><CardTitle className="text-base">Dados da cobrança</CardTitle></CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField control={form.control} name="studentId" render={({ field }) => (
                  <FormItem><FormLabel>Aluno *</FormLabel>
                    <Select onValueChange={(v) => field.onChange(Number(v))} defaultValue={field.value ? String(field.value) : undefined}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Selecione o aluno" /></SelectTrigger></FormControl>
                      <SelectContent>{students?.map((s) => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}</SelectContent>
                    </Select><FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="courseId" render={({ field }) => (
                  <FormItem><FormLabel>Curso (opcional)</FormLabel>
                    <Select onValueChange={(v) => field.onChange(v === "none" ? undefined : Number(v))} defaultValue="none">
                      <FormControl><SelectTrigger><SelectValue placeholder="Nenhum" /></SelectTrigger></FormControl>
                      <SelectContent><SelectItem value="none">Nenhum</SelectItem>{courses?.map((c) => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}</SelectContent>
                    </Select><FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="description" render={({ field }) => (<FormItem className="sm:col-span-2"><FormLabel>Descricao *</FormLabel><FormControl><Input placeholder="Ex: Mensalidade Maio/2026" {...field} /></FormControl><FormMessage /></FormItem>)} />
                <FormField control={form.control} name="amount" render={({ field }) => (<FormItem><FormLabel>Valor (R$) *</FormLabel><FormControl><Input type="number" min={0} step="0.01" {...field} /></FormControl><FormMessage /></FormItem>)} />
                <FormField control={form.control} name="dueDate" render={({ field }) => (<FormItem><FormLabel>Vencimento *</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>)} />
                <FormField control={form.control} name="status" render={({ field }) => (
                  <FormItem><FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent><SelectItem value="pending">Pendente</SelectItem><SelectItem value="paid">Pago</SelectItem><SelectItem value="overdue">Atrasado</SelectItem></SelectContent>
                    </Select><FormMessage />
                  </FormItem>
                )} />
              </div>
              <div className="flex gap-3 pt-2">
                <Button type="submit" disabled={createMutation.isPending}>{createMutation.isPending ? "Salvando..." : "Criar Cobrança"}</Button>
                <Link href="/financeiro"><Button type="button" variant="outline">Cancelar</Button></Link>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
