"use client";

import { useGetDashboardSummary, useGetRecentActivity, useGetFinancialReport } from "@workspace/api-client-react";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { Users, DollarSign, AlertTriangle, TrendingUp, Activity } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { cn } from "@/lib/utils";

function KpiCard({
  title,
  value,
  sub,
  icon: Icon,
  color,
}: {
  title: string;
  value: string | number;
  sub?: string;
  icon: React.ElementType;
  color: string;
}) {
  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-muted-foreground font-medium">{title}</p>
            <p className="text-2xl font-bold mt-1">{value}</p>
            {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
          </div>
          <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0", color)}>
            <Icon className="w-5 h-5 text-white" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

const activityTypeLabel: Record<string, string> = {
  enrollment: "Matricula",
  payment: "Financeiro",
  student: "Aluno",
  course: "Curso",
};

const activityTypeColor: Record<string, string> = {
  enrollment: "bg-blue-100 text-blue-700",
  payment: "bg-green-100 text-green-700",
  student: "bg-purple-100 text-purple-700",
  course: "bg-orange-100 text-orange-700",
};

export default function Dashboard() {
  const { data: summary, isLoading: loadingKpi } = useGetDashboardSummary();
  const { data: activity, isLoading: loadingActivity } = useGetRecentActivity();
  const { data: report, isLoading: loadingReport } = useGetFinancialReport();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground text-sm mt-1">Visao geral do seu sistema</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {loadingKpi ? (
          Array.from({ length: 4 }).map((_, i) => (
            <Card key={i}><CardContent className="p-5"><div className="h-16 bg-muted animate-pulse rounded" /></CardContent></Card>
          ))
        ) : summary ? (
          <>
            <KpiCard title="Alunos Ativos" value={summary.activeStudents} sub={`${summary.activeCourses} cursos ativos`} icon={Users} color="bg-primary" />
            <KpiCard title="Receita do Mes" value={formatCurrency(summary.totalRevenueThisMonth)} sub={`Total: ${formatCurrency(summary.totalRevenueAllTime)}`} icon={TrendingUp} color="bg-green-500" />
            <KpiCard title="Pendentes" value={formatCurrency(summary.pendingPaymentsTotal)} sub={`${summary.pendingPaymentsCount} cobrancas`} icon={DollarSign} color="bg-yellow-500" />
            <KpiCard title="Atrasados" value={formatCurrency(summary.overduePaymentsTotal)} sub={`${summary.overduePaymentsCount} em atraso`} icon={AlertTriangle} color="bg-red-500" />
          </>
        ) : null}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <Card className="xl:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold">Financeiro Mensal</CardTitle>
          </CardHeader>
          <CardContent>
            {loadingReport ? (
              <div className="h-56 bg-muted animate-pulse rounded" />
            ) : report && report.length > 0 ? (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={report} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-40" />
                  <XAxis dataKey="monthLabel" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `R$${(v / 1000).toFixed(0)}k`} />
                  <Tooltip formatter={(v: number) => formatCurrency(v)} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="revenue" name="Recebido" fill="hsl(221 83% 33%)" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="pending" name="Pendente" fill="hsl(38 92% 50%)" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="overdue" name="Atrasado" fill="hsl(0 84% 60%)" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-56 flex items-center justify-center text-muted-foreground text-sm">Nenhum dado financeiro disponivel</div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-muted-foreground" />
              <CardTitle className="text-base font-semibold">Atividade Recente</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {loadingActivity ? (
              <div className="p-4 space-y-3">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-10 bg-muted animate-pulse rounded" />)}</div>
            ) : activity && activity.length > 0 ? (
              <ul className="divide-y">
                {activity.slice(0, 8).map((item) => (
                  <li key={item.id} className="px-4 py-3 flex items-start gap-3">
                    <span className={cn("text-[10px] font-semibold px-1.5 py-0.5 rounded flex-shrink-0 mt-0.5", activityTypeColor[item.type] ?? "bg-gray-100 text-gray-600")}>
                      {activityTypeLabel[item.type] ?? item.type}
                    </span>
                    <div className="min-w-0">
                      <p className="text-sm leading-snug">{item.description}</p>
                      <p className="text-[11px] text-muted-foreground mt-0.5">{formatDateTime(item.createdAt)}</p>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="p-6 text-center text-muted-foreground text-sm">Nenhuma atividade recente</div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
