"use client";

import { useGetFinancialReport, getGetFinancialReportQueryKey, useListOverduePayments, getListOverduePaymentsQueryKey, useGetDashboardSummary, getGetDashboardSummaryQueryKey, useMarkPaymentAsPaid } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatCurrency, formatDate } from "@/lib/format";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, AlertTriangle, TrendingUp, DollarSign } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function ReportsPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: report, isLoading: loadingReport } = useGetFinancialReport();
  const { data: overdue, isLoading: loadingOverdue } = useListOverduePayments();
  const { data: summary } = useGetDashboardSummary();
  const markPaidMutation = useMarkPaymentAsPaid();

  function handleMarkPaid(id: number) {
    markPaidMutation.mutate({ id }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListOverduePaymentsQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetFinancialReportQueryKey() }); toast({ title: "Pagamento confirmado!" }); },
      onError: () => toast({ title: "Erro ao confirmar pagamento", variant: "destructive" }),
    });
  }

  const overdueTotal = overdue?.reduce((s, p) => s + p.amount, 0) ?? 0;

  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold tracking-tight">Relatorios</h1><p className="text-muted-foreground text-sm mt-1">Visao financeira e analitica</p></div>

      {summary && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <Card><CardContent className="p-4"><div className="flex items-center gap-2 mb-1"><TrendingUp className="w-4 h-4 text-green-500" /><p className="text-xs text-muted-foreground">Receita Total</p></div><p className="text-xl font-bold">{formatCurrency(summary.totalRevenueAllTime)}</p></CardContent></Card>
          <Card><CardContent className="p-4"><div className="flex items-center gap-2 mb-1"><DollarSign className="w-4 h-4 text-yellow-500" /><p className="text-xs text-muted-foreground">A Receber</p></div><p className="text-xl font-bold">{formatCurrency(summary.pendingPaymentsTotal)}</p><p className="text-xs text-muted-foreground">{summary.pendingPaymentsCount} cobrancas</p></CardContent></Card>
          <Card><CardContent className="p-4"><div className="flex items-center gap-2 mb-1"><AlertTriangle className="w-4 h-4 text-red-500" /><p className="text-xs text-muted-foreground">Atrasado</p></div><p className="text-xl font-bold text-red-600">{formatCurrency(summary.overduePaymentsTotal)}</p><p className="text-xs text-muted-foreground">{summary.overduePaymentsCount} cobrancas</p></CardContent></Card>
          <Card><CardContent className="p-4"><div className="flex items-center gap-2 mb-1"><TrendingUp className="w-4 h-4 text-primary" /><p className="text-xs text-muted-foreground">Mes Atual</p></div><p className="text-xl font-bold text-primary">{formatCurrency(summary.totalRevenueThisMonth)}</p></CardContent></Card>
        </div>
      )}

      <Card>
        <CardHeader><CardTitle className="text-base font-semibold">Financeiro por Mes</CardTitle></CardHeader>
        <CardContent>
          {loadingReport ? (
            <div className="h-64 bg-muted animate-pulse rounded" />
          ) : report && report.length > 0 ? (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={report} margin={{ top: 4, right: 12, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-40" />
                <XAxis dataKey="monthLabel" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `R$${(v / 1000).toFixed(0)}k`} />
                <Tooltip formatter={(v: number) => formatCurrency(v)} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="revenue" name="Recebido" fill="hsl(221 83% 33%)" radius={[3, 3, 0, 0]} />
                <Bar dataKey="pending" name="Pendente" fill="hsl(38 92% 50%)" radius={[3, 3, 0, 0]} />
                <Bar dataKey="overdue" name="Atrasado" fill="hsl(0 84% 60%)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-64 flex items-center justify-center text-muted-foreground text-sm">Nenhum dado disponivel</div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-500" />
            <CardTitle className="text-base font-semibold">Pagamentos Atrasados{overdue && overdue.length > 0 && <span className="ml-2 text-sm font-normal text-muted-foreground">({overdue.length} — {formatCurrency(overdueTotal)})</span>}</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {loadingOverdue ? (
            <div className="p-4 space-y-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-10 bg-muted animate-pulse rounded" />)}</div>
          ) : !overdue || overdue.length === 0 ? (
            <div className="p-8 text-center"><CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-2" /><p className="text-sm text-muted-foreground">Nenhum pagamento atrasado</p></div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b text-left"><th className="px-4 py-2.5 font-medium text-muted-foreground">Aluno</th><th className="px-4 py-2.5 font-medium text-muted-foreground hidden sm:table-cell">Descricao</th><th className="px-4 py-2.5 font-medium text-muted-foreground">Vencimento</th><th className="px-4 py-2.5 font-medium text-muted-foreground">Valor</th><th className="px-4 py-2.5 font-medium text-muted-foreground text-right">Acoes</th></tr></thead>
                <tbody className="divide-y">
                  {overdue.map((p) => (
                    <tr key={p.id} className="bg-red-50/50">
                      <td className="px-4 py-3 font-medium">{p.studentName}</td>
                      <td className="px-4 py-3 text-muted-foreground hidden sm:table-cell">{p.description}</td>
                      <td className="px-4 py-3 text-red-600">{formatDate(p.dueDate)}</td>
                      <td className="px-4 py-3 font-semibold">{formatCurrency(p.amount)}</td>
                      <td className="px-4 py-3"><div className="flex justify-end"><Button variant="ghost" size="sm" className="h-7 text-green-600 hover:text-green-700 text-xs" onClick={() => handleMarkPaid(p.id)} disabled={markPaidMutation.isPending}><CheckCircle className="w-3.5 h-3.5 mr-1" />Confirmar</Button></div></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
