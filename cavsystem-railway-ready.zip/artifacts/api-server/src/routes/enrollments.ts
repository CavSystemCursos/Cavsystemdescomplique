import { Router, type IRouter } from "express";
import { db, enrollmentsTable, studentsTable, coursesTable, activityLogTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  CreateEnrollmentBody,
  DeleteEnrollmentParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/enrollments", async (req, res) => {
  const rows = await db
    .select({
      id: enrollmentsTable.id,
      studentId: enrollmentsTable.studentId,
      courseId: enrollmentsTable.courseId,
      enrolledAt: enrollmentsTable.enrolledAt,
      status: enrollmentsTable.status,
      studentName: studentsTable.name,
      studentEmail: studentsTable.email,
      courseName: coursesTable.name,
      coursePrice: coursesTable.price,
    })
    .from(enrollmentsTable)
    .innerJoin(studentsTable, eq(enrollmentsTable.studentId, studentsTable.id))
    .innerJoin(coursesTable, eq(enrollmentsTable.courseId, coursesTable.id))
    .orderBy(enrollmentsTable.enrolledAt);
  res.json(rows.map(r => ({ ...r, coursePrice: Number(r.coursePrice) })));
});

router.post("/enrollments", async (req, res) => {
  const body = CreateEnrollmentBody.parse(req.body);
  const [enrollment] = await db.insert(enrollmentsTable).values(body).returning();

  const student = await db.query.studentsTable.findFirst({ where: eq(studentsTable.id, body.studentId) });
  const course = await db.query.coursesTable.findFirst({ where: eq(coursesTable.id, body.courseId) });

  await db.insert(activityLogTable).values({
    type: "enrollment",
    description: `${student?.name ?? "Aluno"} matriculado em ${course?.name ?? "curso"}`,
  });

  const [row] = await db
    .select({
      id: enrollmentsTable.id,
      studentId: enrollmentsTable.studentId,
      courseId: enrollmentsTable.courseId,
      enrolledAt: enrollmentsTable.enrolledAt,
      status: enrollmentsTable.status,
      studentName: studentsTable.name,
      studentEmail: studentsTable.email,
      courseName: coursesTable.name,
      coursePrice: coursesTable.price,
    })
    .from(enrollmentsTable)
    .innerJoin(studentsTable, eq(enrollmentsTable.studentId, studentsTable.id))
    .innerJoin(coursesTable, eq(enrollmentsTable.courseId, coursesTable.id))
    .where(eq(enrollmentsTable.id, enrollment.id));
  res.status(201).json({ ...row, coursePrice: Number(row.coursePrice) });
});

router.delete("/enrollments/:id", async (req, res) => {
  const { id } = DeleteEnrollmentParams.parse({ id: Number(req.params.id) });
  await db.delete(enrollmentsTable).where(eq(enrollmentsTable.id, id));
  res.status(204).end();
});

export default router;
