import { Router, type IRouter } from "express";
import { db, paymentsTable, studentsTable, coursesTable, activityLogTable } from "@workspace/db";
import { eq, and, lte } from "drizzle-orm";
import {
  ListPaymentsQueryParams,
  CreatePaymentBody,
  GetPaymentParams,
  UpdatePaymentBody,
  UpdatePaymentParams,
  DeletePaymentParams,
  MarkPaymentAsPaidParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

async function getPaymentWithDetails(id: number) {
  const [row] = await db
    .select({
      id: paymentsTable.id,
      studentId: paymentsTable.studentId,
      courseId: paymentsTable.courseId,
      enrollmentId: paymentsTable.enrollmentId,
      description: paymentsTable.description,
      amount: paymentsTable.amount,
      dueDate: paymentsTable.dueDate,
      paidAt: paymentsTable.paidAt,
      status: paymentsTable.status,
      createdAt: paymentsTable.createdAt,
      studentName: studentsTable.name,
      courseName: coursesTable.name,
    })
    .from(paymentsTable)
    .innerJoin(studentsTable, eq(paymentsTable.studentId, studentsTable.id))
    .leftJoin(coursesTable, eq(paymentsTable.courseId, coursesTable.id))
    .where(eq(paymentsTable.id, id));
  if (!row) return null;
  return { ...row, amount: Number(row.amount) };
}

router.get("/payments", async (req, res) => {
  const query = ListPaymentsQueryParams.parse(req.query);
  const conditions: any[] = [];
  if (query.status) conditions.push(eq(paymentsTable.status, query.status));
  if (query.studentId) conditions.push(eq(paymentsTable.studentId, query.studentId));

  const rows = await db
    .select({
      id: paymentsTable.id,
      studentId: paymentsTable.studentId,
      courseId: paymentsTable.courseId,
      enrollmentId: paymentsTable.enrollmentId,
      description: paymentsTable.description,
      amount: paymentsTable.amount,
      dueDate: paymentsTable.dueDate,
      paidAt: paymentsTable.paidAt,
      status: paymentsTable.status,
      createdAt: paymentsTable.createdAt,
      studentName: studentsTable.name,
      courseName: coursesTable.name,
    })
    .from(paymentsTable)
    .innerJoin(studentsTable, eq(paymentsTable.studentId, studentsTable.id))
    .leftJoin(coursesTable, eq(paymentsTable.courseId, coursesTable.id))
    .where(conditions.length === 0 ? undefined : conditions.length === 1 ? conditions[0] : and(...conditions))
    .orderBy(paymentsTable.dueDate);
  res.json(rows.map(r => ({ ...r, amount: Number(r.amount) })));
});

router.post("/payments", async (req, res) => {
  const body = CreatePaymentBody.parse(req.body);
  const [payment] = await db.insert(paymentsTable).values({ ...body, amount: String(body.amount) }).returning();

  const student = await db.query.studentsTable.findFirst({ where: eq(studentsTable.id, body.studentId) });
  await db.insert(activityLogTable).values({
    type: "payment",
    description: `Cobrança criada para ${student?.name ?? "aluno"}: R$ ${Number(body.amount).toFixed(2)}`,
  });

  const result = await getPaymentWithDetails(payment.id);
  res.status(201).json(result);
});

router.get("/payments/overdue", async (req, res) => {
  const today = new Date().toISOString().slice(0, 10);
  const rows = await db
    .select({
      id: paymentsTable.id,
      studentId: paymentsTable.studentId,
      courseId: paymentsTable.courseId,
      enrollmentId: paymentsTable.enrollmentId,
      description: paymentsTable.description,
      amount: paymentsTable.amount,
      dueDate: paymentsTable.dueDate,
      paidAt: paymentsTable.paidAt,
      status: paymentsTable.status,
      createdAt: paymentsTable.createdAt,
      studentName: studentsTable.name,
      courseName: coursesTable.name,
    })
    .from(paymentsTable)
    .innerJoin(studentsTable, eq(paymentsTable.studentId, studentsTable.id))
    .leftJoin(coursesTable, eq(paymentsTable.courseId, coursesTable.id))
    .where(eq(paymentsTable.status, "overdue"))
    .orderBy(paymentsTable.dueDate);
  res.json(rows.map(r => ({ ...r, amount: Number(r.amount) })));
});

router.get("/payments/:id", async (req, res) => {
  const { id } = GetPaymentParams.parse({ id: Number(req.params.id) });
  const result = await getPaymentWithDetails(id);
  if (!result) return res.status(404).json({ error: "Pagamento não encontrado" });
  res.json(result);
});

router.patch("/payments/:id", async (req, res) => {
  const { id } = UpdatePaymentParams.parse({ id: Number(req.params.id) });
  const body = UpdatePaymentBody.parse(req.body);
  const updateData: any = { ...body };
  if (body.amount !== undefined) updateData.amount = String(body.amount);
  await db.update(paymentsTable).set(updateData).where(eq(paymentsTable.id, id));
  const result = await getPaymentWithDetails(id);
  if (!result) return res.status(404).json({ error: "Pagamento não encontrado" });
  res.json(result);
});

router.delete("/payments/:id", async (req, res) => {
  const { id } = DeletePaymentParams.parse({ id: Number(req.params.id) });
  await db.delete(paymentsTable).where(eq(paymentsTable.id, id));
  res.status(204).end();
});

router.post("/payments/:id/pay", async (req, res) => {
  const { id } = MarkPaymentAsPaidParams.parse({ id: Number(req.params.id) });
  await db.update(paymentsTable).set({ status: "paid", paidAt: new Date() }).where(eq(paymentsTable.id, id));

  const result = await getPaymentWithDetails(id);
  if (!result) return res.status(404).json({ error: "Pagamento não encontrado" });

  await db.insert(activityLogTable).values({
    type: "payment",
    description: `Pagamento confirmado: ${result.studentName} - R$ ${result.amount.toFixed(2)}`,
  });

  res.json(result);
});

export default router;
