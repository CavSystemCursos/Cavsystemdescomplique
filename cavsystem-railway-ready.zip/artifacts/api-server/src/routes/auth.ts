import { Router } from "express";

declare module "express-session" {
  interface SessionData {
    admin?: boolean;
  }
}

const router = Router();

function getAdminCredentials() {
  return {
    email: process.env["ADMIN_EMAIL"] ?? "admin@cavsystem.com",
    password: process.env["ADMIN_PASSWORD"],
  };
}

router.post("/auth/login", (req, res) => {
  const { email, password } = req.body as { email?: string; password?: string };
  const creds = getAdminCredentials();

  if (!creds.password) {
    res.status(500).json({ error: "Senha do admin nao configurada. Defina ADMIN_PASSWORD." });
    return;
  }

  if (email === creds.email && password === creds.password) {
    req.session.admin = true;
    res.cookie("cavsystem-admin", "1", {
      httpOnly: true,
      sameSite: "lax",
      maxAge: 24 * 60 * 60 * 1000,
    });
    res.json({ success: true });
    return;
  }

  res.status(401).json({ error: "Email ou senha invalidos" });
});

router.post("/auth/logout", (req, res) => {
  req.session.destroy(() => {});
  res.clearCookie("cavsystem-admin");
  res.clearCookie("connect.sid");
  res.json({ success: true });
});

router.get("/auth/me", (req, res) => {
  if (req.session.admin) {
    const email = process.env["ADMIN_EMAIL"] ?? "admin@cavsystem.com";
    res.json({ authenticated: true, email });
    return;
  }
  res.status(401).json({ authenticated: false });
});

export default router;
