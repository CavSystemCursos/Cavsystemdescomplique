import { Router, type IRouter } from "express";
import { db, studentsTable, enrollmentsTable, coursesTable, activityLogTable } from "@workspace/db";
import { eq, ilike, or, count, sql } from "drizzle-orm";
import {
  ListStudentsQueryParams,
  CreateStudentBody,
  GetStudentParams,
  UpdateStudentBody,
  UpdateStudentParams,
  DeleteStudentParams,
  GetStudentEnrollmentsParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/students", async (req, res) => {
  const query = ListStudentsQueryParams.parse(req.query);
  let conditions: any[] = [];
  if (query.status) {
    conditions.push(eq(studentsTable.status, query.status));
  }
  if (query.search) {
    conditions.push(
      or(
        ilike(studentsTable.name, `%${query.search}%`),
        ilike(studentsTable.email, `%${query.search}%`),
      ),
    );
  }

  const rows = await db
    .select({
      id: studentsTable.id,
      name: studentsTable.name,
      email: studentsTable.email,
      phone: studentsTable.phone,
      cpf: studentsTable.cpf,
      status: studentsTable.status,
      notes: studentsTable.notes,
      createdAt: studentsTable.createdAt,
      enrollmentCount: count(enrollmentsTable.id),
    })
    .from(studentsTable)
    .leftJoin(enrollmentsTable, eq(studentsTable.id, enrollmentsTable.studentId))
    .where(conditions.length > 0 ? (conditions.length === 1 ? conditions[0] : sql`${conditions[0]} AND ${conditions[1]}`) : undefined)
    .groupBy(studentsTable.id)
    .orderBy(studentsTable.name);

  res.json(rows.map(r => ({ ...r, enrollmentCount: Number(r.enrollmentCount) })));
});

router.post("/students", async (req, res) => {
  const body = CreateStudentBody.parse(req.body);
  const [student] = await db.insert(studentsTable).values(body).returning();
  await db.insert(activityLogTable).values({
    type: "student",
    description: `Novo aluno cadastrado: ${student.name}`,
  });
  const [withCount] = await db
    .select({ id: studentsTable.id, name: studentsTable.name, email: studentsTable.email, phone: studentsTable.phone, cpf: studentsTable.cpf, status: studentsTable.status, notes: studentsTable.notes, createdAt: studentsTable.createdAt, enrollmentCount: count(enrollmentsTable.id) })
    .from(studentsTable)
    .leftJoin(enrollmentsTable, eq(studentsTable.id, enrollmentsTable.studentId))
    .where(eq(studentsTable.id, student.id))
    .groupBy(studentsTable.id);
  res.status(201).json({ ...withCount, enrollmentCount: Number(withCount.enrollmentCount) });
});

router.get("/students/:id", async (req, res) => {
  const { id } = GetStudentParams.parse({ id: Number(req.params.id) });
  const [row] = await db
    .select({ id: studentsTable.id, name: studentsTable.name, email: studentsTable.email, phone: studentsTable.phone, cpf: studentsTable.cpf, status: studentsTable.status, notes: studentsTable.notes, createdAt: studentsTable.createdAt, enrollmentCount: count(enrollmentsTable.id) })
    .from(studentsTable)
    .leftJoin(enrollmentsTable, eq(studentsTable.id, enrollmentsTable.studentId))
    .where(eq(studentsTable.id, id))
    .groupBy(studentsTable.id);
  if (!row) return res.status(404).json({ error: "Aluno não encontrado" });
  res.json({ ...row, enrollmentCount: Number(row.enrollmentCount) });
});

router.patch("/students/:id", async (req, res) => {
  const { id } = UpdateStudentParams.parse({ id: Number(req.params.id) });
  const body = UpdateStudentBody.parse(req.body);
  await db.update(studentsTable).set(body).where(eq(studentsTable.id, id));
  const [row] = await db
    .select({ id: studentsTable.id, name: studentsTable.name, email: studentsTable.email, phone: studentsTable.phone, cpf: studentsTable.cpf, status: studentsTable.status, notes: studentsTable.notes, createdAt: studentsTable.createdAt, enrollmentCount: count(enrollmentsTable.id) })
    .from(studentsTable)
    .leftJoin(enrollmentsTable, eq(studentsTable.id, enrollmentsTable.studentId))
    .where(eq(studentsTable.id, id))
    .groupBy(studentsTable.id);
  if (!row) return res.status(404).json({ error: "Aluno não encontrado" });
  res.json({ ...row, enrollmentCount: Number(row.enrollmentCount) });
});

router.delete("/students/:id", async (req, res) => {
  const { id } = DeleteStudentParams.parse({ id: Number(req.params.id) });
  await db.delete(studentsTable).where(eq(studentsTable.id, id));
  res.status(204).end();
});

router.get("/students/:id/enrollments", async (req, res) => {
  const { id } = GetStudentEnrollmentsParams.parse({ id: Number(req.params.id) });
  const rows = await db
    .select({
      id: enrollmentsTable.id,
      studentId: enrollmentsTable.studentId,
      courseId: enrollmentsTable.courseId,
      enrolledAt: enrollmentsTable.enrolledAt,
      status: enrollmentsTable.status,
      studentName: studentsTable.name,
      studentEmail: studentsTable.email,
      courseName: coursesTable.name,
      coursePrice: coursesTable.price,
    })
    .from(enrollmentsTable)
    .innerJoin(studentsTable, eq(enrollmentsTable.studentId, studentsTable.id))
    .innerJoin(coursesTable, eq(enrollmentsTable.courseId, coursesTable.id))
    .where(eq(enrollmentsTable.studentId, id))
    .orderBy(enrollmentsTable.enrolledAt);
  res.json(rows.map(r => ({ ...r, coursePrice: Number(r.coursePrice) })));
});

export default router;
