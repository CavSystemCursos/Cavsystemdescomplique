import { Router, type IRouter } from "express";
import { db, coursesTable, enrollmentsTable, studentsTable, activityLogTable } from "@workspace/db";
import { eq, count } from "drizzle-orm";
import {
  ListCoursesQueryParams,
  CreateCourseBody,
  GetCourseParams,
  UpdateCourseBody,
  UpdateCourseParams,
  DeleteCourseParams,
  GetCourseStudentsParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/courses", async (req, res) => {
  const query = ListCoursesQueryParams.parse(req.query);
  const rows = await db
    .select({
      id: coursesTable.id,
      name: coursesTable.name,
      description: coursesTable.description,
      price: coursesTable.price,
      durationHours: coursesTable.durationHours,
      status: coursesTable.status,
      whatsappGroupLink: coursesTable.whatsappGroupLink,
      createdAt: coursesTable.createdAt,
      studentCount: count(enrollmentsTable.id),
    })
    .from(coursesTable)
    .leftJoin(enrollmentsTable, eq(coursesTable.id, enrollmentsTable.courseId))
    .where(query.status ? eq(coursesTable.status, query.status) : undefined)
    .groupBy(coursesTable.id)
    .orderBy(coursesTable.name);
  res.json(rows.map(r => ({ ...r, price: Number(r.price), studentCount: Number(r.studentCount) })));
});

router.post("/courses", async (req, res) => {
  const body = CreateCourseBody.parse(req.body);
  const [course] = await db.insert(coursesTable).values({ ...body, price: String(body.price) }).returning();
  await db.insert(activityLogTable).values({
    type: "course",
    description: `Novo curso criado: ${course.name}`,
  });
  const [withCount] = await db
    .select({ id: coursesTable.id, name: coursesTable.name, description: coursesTable.description, price: coursesTable.price, durationHours: coursesTable.durationHours, status: coursesTable.status, whatsappGroupLink: coursesTable.whatsappGroupLink, createdAt: coursesTable.createdAt, studentCount: count(enrollmentsTable.id) })
    .from(coursesTable)
    .leftJoin(enrollmentsTable, eq(coursesTable.id, enrollmentsTable.courseId))
    .where(eq(coursesTable.id, course.id))
    .groupBy(coursesTable.id);
  res.status(201).json({ ...withCount, price: Number(withCount.price), studentCount: Number(withCount.studentCount) });
});

router.get("/courses/:id", async (req, res) => {
  const { id } = GetCourseParams.parse({ id: Number(req.params.id) });
  const [row] = await db
    .select({ id: coursesTable.id, name: coursesTable.name, description: coursesTable.description, price: coursesTable.price, durationHours: coursesTable.durationHours, status: coursesTable.status, whatsappGroupLink: coursesTable.whatsappGroupLink, createdAt: coursesTable.createdAt, studentCount: count(enrollmentsTable.id) })
    .from(coursesTable)
    .leftJoin(enrollmentsTable, eq(coursesTable.id, enrollmentsTable.courseId))
    .where(eq(coursesTable.id, id))
    .groupBy(coursesTable.id);
  if (!row) return res.status(404).json({ error: "Curso não encontrado" });
  res.json({ ...row, price: Number(row.price), studentCount: Number(row.studentCount) });
});

router.patch("/courses/:id", async (req, res) => {
  const { id } = UpdateCourseParams.parse({ id: Number(req.params.id) });
  const body = UpdateCourseBody.parse(req.body);
  const updateData: any = { ...body };
  if (body.price !== undefined) updateData.price = String(body.price);
  await db.update(coursesTable).set(updateData).where(eq(coursesTable.id, id));
  const [row] = await db
    .select({ id: coursesTable.id, name: coursesTable.name, description: coursesTable.description, price: coursesTable.price, durationHours: coursesTable.durationHours, status: coursesTable.status, whatsappGroupLink: coursesTable.whatsappGroupLink, createdAt: coursesTable.createdAt, studentCount: count(enrollmentsTable.id) })
    .from(coursesTable)
    .leftJoin(enrollmentsTable, eq(coursesTable.id, enrollmentsTable.courseId))
    .where(eq(coursesTable.id, id))
    .groupBy(coursesTable.id);
  if (!row) return res.status(404).json({ error: "Curso não encontrado" });
  res.json({ ...row, price: Number(row.price), studentCount: Number(row.studentCount) });
});

router.delete("/courses/:id", async (req, res) => {
  const { id } = DeleteCourseParams.parse({ id: Number(req.params.id) });
  await db.delete(coursesTable).where(eq(coursesTable.id, id));
  res.status(204).end();
});

router.get("/courses/:id/students", async (req, res) => {
  const { id } = GetCourseStudentsParams.parse({ id: Number(req.params.id) });
  const rows = await db
    .select({
      id: studentsTable.id,
      name: studentsTable.name,
      email: studentsTable.email,
      phone: studentsTable.phone,
      cpf: studentsTable.cpf,
      status: studentsTable.status,
      notes: studentsTable.notes,
      createdAt: studentsTable.createdAt,
      enrollmentCount: count(enrollmentsTable.id),
    })
    .from(studentsTable)
    .innerJoin(enrollmentsTable, eq(studentsTable.id, enrollmentsTable.studentId))
    .where(eq(enrollmentsTable.courseId, id))
    .groupBy(studentsTable.id);
  res.json(rows.map(r => ({ ...r, enrollmentCount: Number(r.enrollmentCount) })));
});

export default router;
