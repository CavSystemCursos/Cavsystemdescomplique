import { Router, type IRouter } from "express";
import healthRouter from "./health";
import studentsRouter from "./students";
import coursesRouter from "./courses";
import enrollmentsRouter from "./enrollments";
import paymentsRouter from "./payments";
import dashboardRouter from "./dashboard";
import authRouter from "./auth";

const router: IRouter = Router();

router.use(authRouter);
router.use(healthRouter);
router.use(studentsRouter);
router.use(coursesRouter);
router.use(enrollmentsRouter);
router.use(paymentsRouter);
router.use(dashboardRouter);

export default router;
