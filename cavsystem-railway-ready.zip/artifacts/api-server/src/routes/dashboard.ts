import { Router, type IRouter } from "express";
import { db, studentsTable, coursesTable, paymentsTable, enrollmentsTable, activityLogTable } from "@workspace/db";
import { eq, sum, count, and, lte } from "drizzle-orm";
import { sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/dashboard/summary", async (req, res) => {
  const today = new Date().toISOString().slice(0, 10);
  const thisMonth = new Date();
  const firstOfMonth = new Date(thisMonth.getFullYear(), thisMonth.getMonth(), 1).toISOString().slice(0, 10);

  const [activeStudents] = await db
    .select({ count: count() })
    .from(studentsTable)
    .where(eq(studentsTable.status, "active"));

  const [activeCourses] = await db
    .select({ count: count() })
    .from(coursesTable)
    .where(eq(coursesTable.status, "active"));

  const [pendingAgg] = await db
    .select({ count: count(), total: sum(paymentsTable.amount) })
    .from(paymentsTable)
    .where(eq(paymentsTable.status, "pending"));

  const [overdueAgg] = await db
    .select({ count: count(), total: sum(paymentsTable.amount) })
    .from(paymentsTable)
    .where(eq(paymentsTable.status, "overdue"));

  const [revenueThisMonth] = await db
    .select({ total: sum(paymentsTable.amount) })
    .from(paymentsTable)
    .where(
      and(
        eq(paymentsTable.status, "paid"),
        sql`${paymentsTable.paidAt} >= ${firstOfMonth}::date`,
      ),
    );

  const [revenueAll] = await db
    .select({ total: sum(paymentsTable.amount) })
    .from(paymentsTable)
    .where(eq(paymentsTable.status, "paid"));

  res.json({
    activeStudents: Number(activeStudents.count),
    activeCourses: Number(activeCourses.count),
    pendingPaymentsCount: Number(pendingAgg.count),
    pendingPaymentsTotal: Number(pendingAgg.total ?? 0),
    overduePaymentsCount: Number(overdueAgg.count),
    overduePaymentsTotal: Number(overdueAgg.total ?? 0),
    totalRevenueThisMonth: Number(revenueThisMonth.total ?? 0),
    totalRevenueAllTime: Number(revenueAll.total ?? 0),
  });
});

router.get("/dashboard/financial-report", async (req, res) => {
  const result = await db.execute(sql`
    SELECT
      EXTRACT(MONTH FROM due_date::date)::int AS month,
      EXTRACT(YEAR FROM due_date::date)::int AS year,
      TO_CHAR(due_date::date, 'Mon/YY') AS month_label,
      SUM(CASE WHEN status = 'paid' THEN amount::numeric ELSE 0 END) AS revenue,
      SUM(CASE WHEN status = 'pending' THEN amount::numeric ELSE 0 END) AS pending,
      SUM(CASE WHEN status = 'overdue' THEN amount::numeric ELSE 0 END) AS overdue
    FROM payments
    GROUP BY EXTRACT(YEAR FROM due_date::date), EXTRACT(MONTH FROM due_date::date), TO_CHAR(due_date::date, 'Mon/YY')
    ORDER BY year, month
    LIMIT 12
  `);

  const rows: any[] = Array.isArray(result) ? result : (result as any).rows ?? [];

  res.json(
    rows.map((r: any) => ({
      month: Number(r.month),
      year: Number(r.year),
      monthLabel: r.month_label,
      revenue: Number(r.revenue),
      pending: Number(r.pending),
      overdue: Number(r.overdue),
    })),
  );
});

router.get("/dashboard/recent-activity", async (req, res) => {
  const rows = await db
    .select()
    .from(activityLogTable)
    .orderBy(sql`${activityLogTable.createdAt} DESC`)
    .limit(20);
  res.json(rows);
});

export default router;
